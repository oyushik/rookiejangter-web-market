export const PORTONE_STORE_ID = "imp66268461";
export const PORTONE_CHANNEL_KEY = "channel-key-4e5252a2-3160-4d04-ad2f-0a6199721fee";
export const PORTONE_REDIRECT_URL = "http://localhost:5173/signup";